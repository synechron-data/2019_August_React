/* eslint-disable */
import React from 'react';
import ErrorHandler from './common/ErrorHandler';
import ParentComponent from './1_PropDrilling';
import ContextParentComponent from './2_ContextAPI';

class RootComponent extends React.Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <ParentComponent/> */}
                    <ContextParentComponent />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;