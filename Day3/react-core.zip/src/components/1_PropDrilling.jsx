import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from '../services/post.service';

class ChildOne extends Component {
    render() {
        return (
            <ChildTwo data2={this.props.data1}/>
        );
    }
}

class ChildTwo extends Component {
    render() {
        return (
            <DataTable items={this.props.data2}>
                <h4 className="text-success">Posts Table</h4>
            </DataTable>
        );
    }
}



class ParentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h3 className="text-warning">{this.state.message}</h3>
                </div>

                <ChildOne data1={this.state.posts} />
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then((data) => {
            this.setState({ posts: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        });
    }
}

export default ParentComponent;