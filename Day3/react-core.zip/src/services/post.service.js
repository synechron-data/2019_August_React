const url = "https://jsonplaceholder.typicode.com/posts";

const postAPIClient = {
    getAllPosts: function () {
        var promise = new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((data) => {
                    resolve(data);
                }, (err) => {
                    reject("Parsing Error...");
                })
            }, (err) => {
                reject("Communication Error...");
            })
        });
        return promise;
    }
};

export default postAPIClient;