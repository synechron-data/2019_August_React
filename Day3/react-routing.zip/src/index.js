import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'jquery';
import 'bootstrap';

import './index.css';
import RootComponent from './components/root/RootComponent';
import { BrowserRouter } from "react-router-dom";

ReactDOM.render(<BrowserRouter>
    <RootComponent />
</BrowserRouter>, document.getElementById('root'));