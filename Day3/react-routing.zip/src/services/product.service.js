import authenticator from "./authenticator.service";

const url = "http://localhost:8000/api/products";

const productAPIClient = {
    getAllProducts: function () {
        var promise = new Promise((resolve, reject) => {

            let fData = {
                method: 'GET',
                headers: {
                    "accept": "application/json",
                    "x-access-token": authenticator.getToken()
                }
            };

            fetch(url, fData).then((response) => {
                response.json().then((data) => {
                    if (data.success)
                        resolve(data.data);
                    else
                        reject(data.message);
                }, (err) => {
                    reject("Parsing Error...");
                })
            }, (err) => {
                reject("Communication Error...");
            });
        });
        return promise;
    }
}

export default productAPIClient;