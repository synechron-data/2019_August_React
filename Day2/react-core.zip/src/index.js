import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'jquery';
import 'bootstrap';

import './index.css';
import RootComponent from './components/RootComponent';

ReactDOM.render(<RootComponent/>, document.getElementById('root'));