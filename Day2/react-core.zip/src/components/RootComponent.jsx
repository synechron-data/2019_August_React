/* eslint-disable */
import React from 'react';
import CounterAssignment from './1_CounterAssignment';
import DataFlowAssignment from './2_DataFlowAssignment';
import ControlledVsUncontrolledComponent from './3_ControlledVsUncontrolled';
import CalculatorAssignment from './4_CalculatorAssignment';
import ListRoot from './5_ListComponent';
import FormAssignment from './6_FormAssignment';
import PTRoot from './7_PropTypesDemo';
import ErrorHandler from './common/ErrorHandler';
import AjaxComponent from './8_AjaxComponent';

class RootComponent extends React.Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <CounterAssignment /> */}
                    {/* <DataFlowAssignment /> */}
                    {/* <ControlledVsUncontrolledComponent/> */}
                    {/* <CalculatorAssignment/> */}
                    {/* <ListRoot /> */}
                    {/* <FormAssignment /> */}
                    {/* <PTRoot /> */}
                    <AjaxComponent/>
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;