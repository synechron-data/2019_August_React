import React from 'react';
import PropTypes from 'prop-types';

const Ths = ({ item }) => {
    var ths = Object.keys(item).map((item, index) => {
        return <th key={index}>{item.toUpperCase()}</th>
    });

    return (
        <tr>
            {ths}
        </tr>
    );
};

const Tds = ({ item }) => {
    var tds = Object.values(item).map((item, index) => {
        return <td key={index}>{item}</td>
    });

    return (
        <tr>
            {tds}
        </tr>
    );
};

const DataTable = ({ children, items }) => {
    if (items && items.length) {
        var item = items[0];
        var header_row = <Ths item={item} />
        var body_rows = items.map((item, index) => {
            return <Tds key={index} item={item} />
        })
    }
    return (
        <div className="row">
            {children ? children : null}
            <table className="table table-hover">
                <thead>
                    {header_row}
                </thead>
                <tbody>
                    {body_rows}
                </tbody>
            </table>
        </div>
    );
};

DataTable.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object)
}

export default DataTable;