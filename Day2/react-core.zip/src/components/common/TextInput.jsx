import React from 'react';

const TextInput = ({ name, label, onChange, placeholder, value, readOnly }) => {
    return (
        <div className="form-group">
            <label htmlFor={name}>{label}</label>
            <input type="text"
                className="form-control"
                id={name} name={name}
                value={value}
                onChange={onChange}
                readOnly={readOnly}
                placeholder={placeholder} />
        </div>
    );
};

export default TextInput;