import React, { Component } from 'react';
import DataTable from './common/DataTable';
import postAPIClient from '../services/post.service';

class AjaxComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <React.Fragment>
                <div className="row">
                    <h3 className="text-warning">{this.state.message}</h3>
                </div>
                <DataTable items={this.state.posts}>
                    <h4 className="text-success">Posts Table</h4>
                </DataTable>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postAPIClient.getAllPosts().then((data) => {
            this.setState({ posts: [...data], message: "" });
        }, (eMsg) => {
            this.setState({ message: eMsg });
        });
    }
}

export default AjaxComponent;