// npm install --save bootstrap popper.js jquery
// npm install --save-dev node-sass

import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'jquery';
import 'bootstrap';

import './index.css';
// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// import HelloComponent from './components/1_HelloComponent'
// ReactDOM.render(<HelloComponent />, document.getElementById('root'));

// ReactDOM.render(<ComponentOne />, document.getElementById('root1'));
// ReactDOM.render(<ComponentTwo />, document.getElementById('root2'));

// ReactDOM.render([<ComponentOne/>, <ComponentTwo/>], document.getElementById('root'));

// ReactDOM.render(<React.Fragment>
//     <ComponentOne />
//     <ComponentTwo />
// </React.Fragment>, document.getElementById('root'));

import RootComponent from './components/RootComponent';
ReactDOM.render(<RootComponent/>, document.getElementById('root'));