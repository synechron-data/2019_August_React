import React from 'react';

import './ComponentOne.css';

const ComponentOne = () =>
    <h2 className="text-info card1">Hello from Component One!</h2>;

export default ComponentOne;