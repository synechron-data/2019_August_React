import React from 'react';

import styles from './ComponentOne.module.css';

const ComponentOne = () =>
    <h2 className={`text-info ${styles.card}`}>Hello from Component One!</h2>;

export default ComponentOne;