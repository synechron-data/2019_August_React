import React from 'react';

import styles from './ComponentTwo.module.css';

class ComponentTwo extends React.Component {
    render() {
        return (
            <h2 className={`text-success ${styles.card}`}>Hello from Component Two!</h2>
        );
    }
}

export default ComponentTwo;