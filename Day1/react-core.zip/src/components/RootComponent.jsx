import React from 'react';

// import ComponentOne from './2_multi-components/ComponentOne';
// import ComponentTwo from './2_multi-components/ComponentTwo';

// import ComponentOne from './3_components-with-css/ComponentOne';
// import ComponentTwo from './3_components-with-css/ComponentTwo';

// import ComponentOne from './4_external-css/comp-one/ComponentOne';
// import ComponentTwo from './4_external-css/comp-two/ComponentTwo';

// import ComponentOne from './5_css-modules/comp-one/ComponentOne';
// import ComponentTwo from './5_css-modules/comp-two/ComponentTwo';

import ComponentWithState from './6_ComponentWithState';
import ComponentWithProps from './7_ComponentWithProps';
import ComponentWithBehavior from './8_ComponentWithBehavior';
import EventComponent from './9_ReactEventObject';

class RootComponent extends React.Component {
    render() {
        return (
            <div className="container">
                {/* <ComponentOne />
                <ComponentTwo /> */}

                {/* <ComponentWithState /> */}
                {/* <ComponentWithProps name={"Manish"} pin={411021}/> */}
                {/* <ComponentWithBehavior /> */}
                <EventComponent/>
            </div>
        );
    }
}

export default RootComponent;