import React from 'react';

class HelloComponent extends React.Component {
    render() {
        return (
            <React.Fragment>
                <h2 id="t1" className="text-info">Hello World!</h2>
                <h2>Hello World!</h2>
            </React.Fragment>
        );
    }
}

export default HelloComponent;