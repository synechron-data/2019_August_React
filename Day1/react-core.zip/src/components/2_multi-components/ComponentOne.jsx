// import React from 'react';

// class ComponentOne extends React.Component {
//     render() {
//         return (
//             <h2 className="text-info">Hello from Component One!</h2>
//         );
//     }
// }

// export default ComponentOne;

// -------------------------------------
// import React, { Component } from 'react';

// class ComponentOne extends Component {
//     render() {
//         return (
//             <h2 className="text-info">Hello from Component One!</h2>
//         );
//     }
// }

// export default ComponentOne;

// ------------------------------------------------- Functional Component
// import React from 'react';

// // function ComponentOne() {
// //     return (
// //         <h2 className="text-info">Hello from Component One!</h2>
// //     );
// // }

// const ComponentOne = function () {
//     return (
//         <h2 className="text-info">Hello from Component One!</h2>
//     );
// }

// export default ComponentOne;

// ---------------------------------------------- Arrow Syntax

import React from 'react';

// const ComponentOne = () => {
//     return (
//         <h2 className="text-info">Hello from Component One!</h2>
//     );
// }

const ComponentOne = () =>
    <h2 className="text-info">Hello from Component One!</h2>;

export default ComponentOne;

// export const Component11 = () =>
//     <h2 className="text-info">Hello from Component One!</h2>;

// export const Component12 = () =>
//     <h2 className="text-info">Hello from Component One - Two!</h2>;