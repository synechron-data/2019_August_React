import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        console.log("Ctor, parameter: ", props);
        super(props);
        this.state = { name: "Synechron" };
        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);

        return (
            <div>
                <h2 className="text-info">Name: {this.props.name}</h2>
                <h2 className="text-info">Pin Code: {this.props.pin}</h2>
            </div>
        );
    }
}

export default ComponentWithProps;