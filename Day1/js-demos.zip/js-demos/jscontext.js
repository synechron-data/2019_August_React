class Test {
    constructor() {
        this.count = 1;
    }

    inc() {
        console.log(this);
        this.count += 1;
    }
}

var t = new Test();
// t.inc();
// t.inc();
// t.inc();
// console.log(t.count);

// setInterval(t.inc, 2000);

setInterval(t.inc.bind(t), 2000);
